<?php

namespace App\Console\Commands;

use App\Models\AvailableEntry;
use App\Models\Entry;
use Carbon\Carbon;
use Illuminate\Console\Command;
use GuzzleHttp\Client;
use Symfony\Component\DomCrawler\Crawler;

class ChildEntriesCommand extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'karinthy:child-entries-command';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $this->info('récupération des pages à traiter     '.  Carbon::now()  );
        $entries = Entry::doesntHave('availableEntries')->inRandomOrder()->get();
        $countEntries = count($entries);
        $this->info($countEntries .' pages à traiter     '.  Carbon::now()  );
        foreach ($entries as $key => $entry) {

            $client = new Client();
            $response = $client->get('https://fr.wikipedia.org/wiki/' . $entry->url);
            $crawler = new Crawler((string) $response->getBody());
            $links = $crawler->filter('a')->extract(['href']);
    
            foreach ($links as $link) {
                if (
                    str_starts_with($link, '/wiki/')
                    && !preg_match('(Sp%C3%A9cial:|Aide:|Fichier:|Discussion:|Wikip%C3%A9dia:|Portail:Accueil|Mod%C3%A8le:|Utilisateur:|Discussion_utilisateur:)', $link)
                    ) 
                    {

                    $link = str_replace('/wiki/', '', $link);
                    $title = str_replace('_', ' ', urldecode($link));

                    $linkEntry = Entry::query()
                    ->where('url', $link)
                    ->firstOrCreate([
                        'url' => $link,
                        'title' => $title,
                    ]);
    
                    $availableInEntry = AvailableEntry::query()
                        ->where('parent_entry_id', $entry->id)
                        ->where('child_entry_id', $linkEntry->id)
                        ->firstOrCreate([
                            'parent_entry_id' => $entry->id,
                            'child_entry_id' => $linkEntry->id,
                        ]);
                }
            } 
            $countEntries--;
            $this->info('La page suivante est traité : '. $entry->title. ', il reste '. $countEntries. ' sur '.count($entries).'  '.  Carbon::now());
        }
    }
}
